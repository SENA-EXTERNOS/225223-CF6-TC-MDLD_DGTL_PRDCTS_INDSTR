function ExecuteScript(strId)
{
  switch (strId)
  {
      case "61y8wZSDhzr":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

